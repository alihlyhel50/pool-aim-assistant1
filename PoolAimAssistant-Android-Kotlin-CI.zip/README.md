# Pool Aim Assistant - Native Android (Kotlin)

A practice assistant for 8 Ball Pool running on modern Android versions (Android 10 - 15) and Samsung One UI.

## How to Export an Installable APK

### Option 1: Using Android Studio (Recommended)
1. Download this project using the **Download Complete Android Project (ZIP)** button.
2. Unzip into a folder on your computer.
3. Open **Android Studio** (Koala / Ladybug or newer with JDK 17).
4. Select **File > Open...** and choose the unzipped folder.
5. Wait for Gradle sync to complete.
6. To build the APK:
   - Go to top menu: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
   - Android Studio will generate the APK at:
     `app/build/outputs/apk/debug/app-debug.apk`
   - Click **locate** in the balloon popup notification.
7. Connect your Samsung phone via USB (or send the APK via Quick Share / Google Drive) and install!

### Option 2: Command Line (Gradle)
```bash
# Build Debug APK
./gradlew assembleDebug

# Build Release APK (unsigned or signed)
./gradlew assembleRelease
```
Output file: `app/build/outputs/apk/release/app-release-unsigned.apk`

### Samsung Galaxy Specific Setup
- **One UI "Appear on top"**: Settings > Apps > Special access > Appear on top > Pool Aim Assistant > Allow.
- **Game Booster Exclusion**: If Samsung Game Booster suppresses overlays, open **Game Booster Settings > Block during game > Turn OFF "Floating icons" block**.
- **Battery Optimization**: Go to Settings > Apps > Pool Aim Assistant > Battery > choose **Unrestricted**.

### Legitimacy Notice
This application is a geometric visualizer designed for learning angle calculation, contact point geometry, and cut physics. It does NOT hook game processes, does NOT read memory, and does NOT inject game packages.
