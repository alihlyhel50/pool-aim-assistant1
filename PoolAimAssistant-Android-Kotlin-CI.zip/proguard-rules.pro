# Keep models serialized in SharedPreferences
-keepclassmembers class com.poolaim.assistant.model.** { *; }
-keep class com.poolaim.assistant.model.** { *; }

# Keep service and activity classes
-keep public class com.poolaim.assistant.service.OverlayAimService
-keep public class com.poolaim.assistant.MainActivity
-keep public class com.poolaim.assistant.calibration.TableCalibrationActivity

# Prevent R8 from stripping custom View constructors used by WindowManager
-keep public class com.poolaim.assistant.overlay.** extends android.view.View {
    public <init>(android.content.Context);
    public <init>(android.content.Context, android.util.AttributeSet);
    public <init>(android.content.Context, android.util.AttributeSet, int);
}