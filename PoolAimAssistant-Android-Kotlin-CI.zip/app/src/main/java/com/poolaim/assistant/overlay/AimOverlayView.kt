package com.poolaim.assistant.overlay

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import com.poolaim.assistant.model.TableCalibration
import com.poolaim.assistant.physics.AimGeometry
import kotlin.math.*

/**
 * Custom transparent Android View that draws:
 * 1. Cue Ball marker (draggable)
 * 2. Object Ball marker (draggable)
 * 3. Rotational aiming line
 * 4. Calculated Ghost Ball tangent circle
 * 5. Object ball pocket trajectory ray
 * 6. Specular cushion reflection bounce ray
 */
@SuppressLint("ViewConstructor")
class AimOverlayView(
    context: Context,
    private var calibration: TableCalibration
) : View(context) {

    // Ball coordinates in screen pixels
    private var cueX = 400f
    private var cueY = 600f
    private var targetX = 800f
    private var targetY = 600f
    private var aimAngleRad = 0.0 // Radians

    private var ballRadius = 36f
    private var showCushionBounce = true
    private var isTouchLocked = false

    // Drag tracking
    private var activeDragTarget = DragTarget.NONE
    private var touchStartX = 0f
    private var touchStartY = 0f

    enum class DragTarget {
        NONE, CUE_BALL, TARGET_BALL, AIM_HANDLE
    }

    // Drawing Paints
    private val cuePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.STROKE
        strokeWidth = 4f
    }

    private val targetPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#EAB308") // Gold yellow
        style = Paint.Style.STROKE
        strokeWidth = 4f
    }

    private val aimLinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#38BDF8") // Sky cyan
        strokeWidth = 3f
        pathEffect = DashPathEffect(floatArrayOf(15f, 10f), 0f)
    }

    private val trajectoryPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#22C55E") // Emerald green
        strokeWidth = 5f
    }

    private val bouncePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#F97316") // Orange
        strokeWidth = 4f
        pathEffect = DashPathEffect(floatArrayOf(12f, 8f), 0f)
    }

    private val ghostBallPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#80FFFFFF") // Semi-transparent white
        style = Paint.Style.STROKE
        strokeWidth = 3f
    }

    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 32f
        typeface = Typeface.DEFAULT_BOLD
        setShadowLayer(4f, 2f, 2f, Color.BLACK)
    }

    fun setTouchLocked(locked: Boolean) {
        this.isTouchLocked = locked
        invalidate()
    }

    fun setShowCushionBounce(show: Boolean) {
        this.showCushionBounce = show
        invalidate()
    }

    fun updateCalibration(newCalibration: TableCalibration) {
        this.calibration = newCalibration
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        // Calculate aim geometry
        val result = AimGeometry.calculate(
            cueX = cueX,
            cueY = cueY,
            targetX = targetX,
            targetY = targetY,
            aimAngleRad = aimAngleRad,
            ballRadius = ballRadius,
            table = calibration,
            calculateBounce = showCushionBounce
        )

        // 1. Draw Cue Ball Handle Ring
        canvas.drawCircle(cueX, cueY, ballRadius, cuePaint)
        canvas.drawCircle(cueX, cueY, 6f, cuePaint)

        // 2. Draw Target Ball Ring
        canvas.drawCircle(targetX, targetY, ballRadius, targetPaint)
        canvas.drawCircle(targetX, targetY, 6f, targetPaint)

        // 3. Draw Aim Line from Cue Ball towards Ghost Ball
        val aimEndX = cueX + (cos(aimAngleRad) * 1200).toFloat()
        val aimEndY = cueY + (sin(aimAngleRad) * 1200).toFloat()
        canvas.drawLine(cueX, cueY, aimEndX, aimEndY, aimLinePaint)

        // 4. Draw Ghost Ball at impact location
        result.ghostBall?.let { ghost ->
            canvas.drawCircle(ghost.x, ghost.y, ballRadius, ghostBallPaint)

            // 5. Draw Object Ball Trajectory
            canvas.drawLine(targetX, targetY, result.targetTrajectoryEnd.x, result.targetTrajectoryEnd.y, trajectoryPaint)

            // 6. Draw Cushion Bank Bounce if enabled
            if (showCushionBounce && result.cushionBounceEnd != null) {
                canvas.drawLine(
                    result.targetTrajectoryEnd.x, result.targetTrajectoryEnd.y,
                    result.cushionBounceEnd.x, result.cushionBounceEnd.y,
                    bouncePaint
                )
            }

            // 7. Render cut angle text HUD
            val cutAngleText = String.format("Cut: %.1f°", result.cutAngleDeg)
            canvas.drawText(cutAngleText, targetX - 50f, targetY - ballRadius - 15f, textPaint)
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (isTouchLocked) return false

        val x = event.x
        val y = event.y

        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                touchStartX = x
                touchStartY = y

                // Check which object was touched
                activeDragTarget = when {
                    hypot((x - cueX).toDouble(), (y - cueY).toDouble()) <= ballRadius * 1.5 -> DragTarget.CUE_BALL
                    hypot((x - targetX).toDouble(), (y - targetY).toDouble()) <= ballRadius * 1.5 -> DragTarget.TARGET_BALL
                    else -> DragTarget.AIM_HANDLE
                }
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                when (activeDragTarget) {
                    DragTarget.CUE_BALL -> {
                        cueX = x
                        cueY = y
                        // Automatically point towards target ball
                        aimAngleRad = atan2((targetY - cueY).toDouble(), (targetX - cueX).toDouble())
                    }
                    DragTarget.TARGET_BALL -> {
                        targetX = x
                        targetY = y
                    }
                    DragTarget.AIM_HANDLE -> {
                        // Dragging on screen rotates aiming line relative to cue ball
                        aimAngleRad = atan2((y - cueY).toDouble(), (x - cueX).toDouble())
                    }
                    DragTarget.NONE -> return false
                }
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                activeDragTarget = DragTarget.NONE
                return true
            }
        }
        return super.onTouchEvent(event)
    }
}