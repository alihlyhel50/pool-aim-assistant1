package com.poolaim.assistant.repository

import android.content.Context
import android.content.SharedPreferences
import com.poolaim.assistant.model.TableCalibration

object TableCalibrationRepository {
    private const val PREFS_NAME = "pool_aim_calibration_prefs"
    private const val KEY_LEFT = "calib_left"
    private const val KEY_TOP = "calib_top"
    private const val KEY_RIGHT = "calib_right"
    private const val KEY_BOTTOM = "calib_bottom"
    private const val KEY_POCKET_RADIUS = "calib_pocket_radius"

    private fun getPrefs(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    fun loadCalibration(context: Context): TableCalibration {
        val prefs = getPrefs(context)
        val displayMetrics = context.resources.displayMetrics
        val defaultCalib = TableCalibration.createDefaultPreset(
            displayMetrics.widthPixels.toFloat(),
            displayMetrics.heightPixels.toFloat()
        )

        val left = prefs.getFloat(KEY_LEFT, defaultCalib.left)
        val top = prefs.getFloat(KEY_TOP, defaultCalib.top)
        val right = prefs.getFloat(KEY_RIGHT, defaultCalib.right)
        val bottom = prefs.getFloat(KEY_BOTTOM, defaultCalib.bottom)
        val radius = prefs.getFloat(KEY_POCKET_RADIUS, defaultCalib.pocketRadius)

        return TableCalibration(left, top, right, bottom, radius)
    }

    fun saveCalibration(context: Context, calibration: TableCalibration) {
        getPrefs(context).edit().apply {
            putFloat(KEY_LEFT, calibration.left)
            putFloat(KEY_TOP, calibration.top)
            putFloat(KEY_RIGHT, calibration.right)
            putFloat(KEY_BOTTOM, calibration.bottom)
            putFloat(KEY_POCKET_RADIUS, calibration.pocketRadius)
            apply()
        }
    }
}