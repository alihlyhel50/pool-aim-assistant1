package com.poolaim.assistant.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import com.poolaim.assistant.MainActivity
import com.poolaim.assistant.R
import com.poolaim.assistant.overlay.AimOverlayView
import com.poolaim.assistant.overlay.OverlayControlsView
import com.poolaim.assistant.repository.TableCalibrationRepository

class OverlayAimService : Service() {

    private lateinit var windowManager: WindowManager
    private var aimOverlayView: AimOverlayView? = null
    private var controlsView: OverlayControlsView? = null

    companion object {
        const val ACTION_START = "com.poolaim.assistant.START"
        const val ACTION_STOP = "com.poolaim.assistant.STOP"
        private const val NOTIFICATION_ID = 1001
        private const val CHANNEL_ID = "pool_aim_overlay_channel"
    }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_START, null -> {
                startForegroundWithNotification()
                initOverlays()
            }
        }
        return START_STICKY
    }

    private fun startForegroundWithNotification() {
        val notificationIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, notificationIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Pool Aim Assistant Active")
            .setContentText("Aiming lines overlay is running. Tap to open settings.")
            .setSmallIcon(R.drawable.ic_aim_crosshair)
            .setContentIntent(pendingIntent)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun initOverlays() {
        if (aimOverlayView != null) return

        val calibration = TableCalibrationRepository.loadCalibration(this)

        // 1. Fullscreen Aim Overlay View
        aimOverlayView = AimOverlayView(this, calibration)
        val aimParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            // Crucial: NOT_FOCUSABLE allows interaction; NOT_TOUCH_MODAL allows touches outside handles
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        aimParams.gravity = Gravity.TOP or Gravity.START
        windowManager.addView(aimOverlayView, aimParams)

        // 2. Floating Draggable Control Bubble
        controlsView = OverlayControlsView(
            context = this,
            onLockToggled = { isLocked ->
                aimOverlayView?.setTouchLocked(isLocked)
                updateAimOverlayTouchFlags(isLocked)
            },
            onCushionBounceToggled = { enabled ->
                aimOverlayView?.setShowCushionBounce(enabled)
            },
            onCloseRequested = {
                stopSelf()
            }
        )

        val bubbleParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 80
            y = 200
        }

        controlsView?.layoutParams = bubbleParams
        windowManager.addView(controlsView, bubbleParams)
    }

    /**
     * When locked, aiming lines are frozen and all screen touches pass
     * directly down to 8 Ball Pool with FLAG_NOT_TOUCHABLE!
     */
    private fun updateAimOverlayTouchFlags(isLocked: Boolean) {
        aimOverlayView?.let { view ->
            val params = view.layoutParams as WindowManager.LayoutParams
            if (isLocked) {
                params.flags = params.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            } else {
                params.flags = params.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
            }
            windowManager.updateViewLayout(view, params)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Pool Aim Assistant Overlay",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows active status when aiming overlay is running"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        aimOverlayView?.let { windowManager.removeView(it) }
        controlsView?.let { windowManager.removeView(it) }
        aimOverlayView = null
        controlsView = null
    }

    override fun onBind(intent: Intent?): IBinder? = null
}