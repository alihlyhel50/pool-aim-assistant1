package com.poolaim.assistant.model

import android.graphics.PointF

data class TableCalibration(
    var left: Float,
    var top: Float,
    var right: Float,
    var bottom: Float,
    var pocketRadius: Float = 42f
) {
    companion object {
        fun createDefaultPreset(screenWidth: Float, screenHeight: Float): TableCalibration {
            // Standard 8 Ball Pool table occupies ~85% of screen width and 70% of screen height
            val marginX = screenWidth * 0.08f
            val marginY = screenHeight * 0.15f

            return TableCalibration(
                left = marginX,
                top = marginY,
                right = screenWidth - marginX,
                bottom = screenHeight - marginY,
                pocketRadius = 42f
            )
        }
    }

    fun getPockets(): List<PointF> {
        val midX = (left + right) / 2f
        return listOf(
            PointF(left, top),         // Top-Left
            PointF(midX, top),         // Top-Center
            PointF(right, top),        // Top-Right
            PointF(left, bottom),      // Bottom-Left
            PointF(midX, bottom),      // Bottom-Center
            PointF(right, bottom)      // Bottom-Right
        )
    }
}